from django.apps import AppConfig


class AppsvgConfig(AppConfig):
    name = 'appsvg'
