from .models import Wells
from django import forms


class Wells(forms.ModelForm):
    class Meta:
        model=Wells
        fields = '__all__'