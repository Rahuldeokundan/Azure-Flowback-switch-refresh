from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from azure.cosmos import CosmosClient, PartitionKey
from azure.storage.blob import BlockBlobService, PublicAccess
import requests
import pandas as pd

import pyodbc
import urllib.request
from urllib.error import HTTPError
import json
import os
from pathlib import Path
import datetime
from datetime import timedelta

# Azure Connection Here
endpoint = 'https://sncosmosdb.documents.azure.com:443/'
key = 'ulYE2KTm8REkmTx4BbVUmfscUErNV0uNyShLAa6A3vB1B5iRkDLF0CTJ6I4KBXlQUTQT3HXMIgZqtuZvg6uxRA=='

client = CosmosClient(endpoint, key)
database = client.create_database_if_not_exists(id='sn-repo')

container_name = 'sn-mdm'
container = database.create_container_if_not_exists(
    id=container_name,
    partition_key=PartitionKey(path="/api"),
    offer_throughput=400
)

query = "SELECT * FROM c "

items = list(container.query_items(
    query=query,
    enable_cross_partition_query=True
))

def home(request):
    return render(request, 'home.html')


def switch(request):
# Start Well Filter
    result = {}
    for item in items:
        if item['pad'] in result:
            wells = result[item['pad']]
            if item['well_name'] not in wells:
                wells.append(item['well_name'])
        else:
            wells = []
            wells.append(item['well_name'])
            result[item['pad']] = wells
# End Well Filter

# Start API Filter
    result_api = {}
    for item in items:
        if item['well_name'] in result_api:
            wells = result_api[item['well_name']]

            if item['api'] not in wells:
                wells.append(item['api'])
        else:
            wells = []
            wells.append(item['api'])
            result_api[item['well_name']] = wells

# End API Filter
#Assinged Variable
    flow_not=''
    cyg_not=''
    Well_name_msg=''
    add_status = ''
    success_deleted=''
    date_valid=""
# Start Data Fetching
    if request.method == 'POST':
        source = request.POST['source']
        start_date = request.POST['start_date']
        start_time = request.POST['start_time']
        end_date = request.POST['end_date']
        end_time = request.POST['end_time']
        well_item = request.POST.getlist('well_names')
        print(well_item)
        print(start_date)
        print(source)
        if well_item:
            print('API is There')

 # DateTime assigning in one variable and checking if value not available.
            if start_date and start_time:
                    date_from = start_date + " " + start_time
            else:
                date_from=""
            if end_date and end_time:
                date_to = end_date + " " + end_time
            else:
                date_to=""



# Start API Validation with Well Name
            apis={'api':"", 'date_from':"", 'date_to':"", 'source':""}
            api_list = []
            for x in well_item:
                if x in result_api:
                    for keys, values in result_api.items():
                        if x == keys:
                            api_list.append(values[0])
            apis['api'] = api_list
            apis.update(date_from=date_from)
            apis.update(date_to=date_to)
            apis.update(source=source)
#cecking if empty then enter none value
            apis = {k: None if not v else v for k, v in apis.items()}

            # End API Validation with Well Name
            print(apis)

#Inserting in Dataframe


            df = pd.DataFrame(apis)
            print(df)

#Making Connection to Sql
            server = '10.14.0.16'
            database = 'sn-sql-pool'
            username = 'deorch@sogazcloud'
            password = 'DES0g!2345678'
            driver = '{ODBC Driver 17 for SQL Server}'
            connStr = pyodbc.connect(
                'DRIVER=' + driver + ';SERVER=' + server + ';PORT=1433;DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
            cursor = connStr.cursor()
            print(cursor)


#Inserting dataframe in sql

            for index, row in df.iterrows():
                api_table=row['api']
                source_table=row['source']
                print(api_table)
                print(source_table)

# Checking if flowback selected
                if source_table=='flowback':
                    print(source_table)

# Checking in sql if fowback available
                    cursor.execute("SELECT * FROM dbo.FLOWBACK_CYGNET_SWITCH WHERE api =( ? ) AND source='flowback'",(api_table))
                    check_api=cursor.fetchall()
                    if check_api:

                        print(date_to)
                        print(date_from)
                        print('flowback')

# Incresing 1hr. in date_from
                        cursor.execute("SELECT date_to FROM dbo.FLOWBACK_CYGNET_SWITCH WHERE api =( ? ) AND source='flowback'", (api_table))
                        check_date_to = cursor.fetchall()
                        if not check_date_to==None:
                            print(check_date_to)

                            for check_date_from in check_date_to:
                                date_flow = check_date_from[0]
                                sql_date_from = date_flow + timedelta(hours=1)
                                print(sql_date_from)

                        # Update cygnet if cygnet available
                            print('cyg_update')
                            cursor.execute("UPDATE dbo.FLOWBACK_CYGNET_SWITCH SET date_from=( ? ), date_to=( ? ), source =( ? ) WHERE api= ( ? ) AND source=( ? )",(sql_date_from, date_to, 'cygnet', api_table, 'cygnet'))
                        else:
                            flow_not = 'Flowback end data is not available'
                            connStr.commit()

                    else:
# Inserting flowback
                        print('flow_add')
                        cursor.execute(
                            "INSERT INTO dbo.FLOWBACK_CYGNET_SWITCH ([api],[date_from],[date_to],[source]) VALUES (?,?,?,?)",
                            row['api'], row['date_from'], row['date_to'], row['source'])
                        connStr.commit()

#Incresing 1hr. in date_from
                        cursor.execute("SELECT date_to FROM dbo.FLOWBACK_CYGNET_SWITCH WHERE api =( ? ) AND source='flowback'", (api_table))
                        check_date_to = cursor.fetchall()
                        if not check_date_to==None:
                            print(check_date_to)

                            for check_date_from in check_date_to:
                                date_flow = check_date_from[0]
                                sql_date_from = date_flow + timedelta(hours=1)
                                print(sql_date_from)

    # Flowback Inserting if cygnet available
                            print('cyg_add')
                            cursor.execute(
                                "INSERT INTO dbo.FLOWBACK_CYGNET_SWITCH ([api],[date_to],[date_from],[source]) VALUES (?,?,?,?)",
                                row['api'], date_to, sql_date_from, 'cygnet')
                            connStr.commit()
                        else:
                            flow_not='Flowback end data is not available'
    # Checking if Cygnet Select
                elif source_table == 'cygnet':
                    print(source_table)
                    print('cygnet-print')
    # Check in sql if api with cygnet available
                    cursor.execute("SELECT * FROM dbo.FLOWBACK_CYGNET_SWITCH WHERE api =( ? ) AND source='cygnet'",
                                   (api_table))
                    check_api = cursor.fetchall()
                    if check_api:
                        # updating source with new datetime

                        print(date_to)
                        print(date_from)
                        print('cygnet')

    # Reducing 1hr. in date_to
                        cursor.execute("SELECT date_from FROM dbo.FLOWBACK_CYGNET_SWITCH WHERE api =( ? ) AND source='cygnet'",(api_table))
                        check_date_from = cursor.fetchall()
                        if not check_date_from==None:
                            print(check_date_from)
                            for check_date_to in check_date_from:
                                date_cyg = check_date_to[0]
                                sql_date_to = date_cyg - timedelta(hours=1)
                                print(sql_date_to)

    # cygnet updating if flowback available
                            print('flow_update')
                            cursor.execute(
                                "UPDATE dbo.FLOWBACK_CYGNET_SWITCH SET date_from=( ? ), date_to=( ? ), source =( ? ) WHERE api= ( ? ) AND source=( ? )",
                                (date_from, sql_date_to, 'flowback', api_table, 'flowback'))
                            connStr.commit()
                        else:
                            cyg_not = 'Cygnet Start Date is not available'

                    else:
    # flowback adding if select cygnet
                        print('flow_add')
                        cursor.execute(
                            "INSERT INTO dbo.FLOWBACK_CYGNET_SWITCH ([api],[date_from],[date_to],[source]) VALUES (?,?,?,?)",
                            row['api'], row['date_from'], row['date_to'], row['source'])
                        connStr.commit()

    # Reducing 1hr. in date_to
                        cursor.execute(
                            "SELECT date_from FROM dbo.FLOWBACK_CYGNET_SWITCH WHERE api =( ? ) AND source='cygnet'",
                            (api_table))
                        check_date_from = cursor.fetchall()
                        if not check_date_from==None:
                            print(check_date_from)
                            for check_date_to in check_date_from:
                                date_cyg = check_date_to[0]
                                print(date_cyg)
                                sql_date_to = date_cyg - timedelta(hours=1)
                                print(sql_date_to)


    #cygnet adding if select cygnet
                            print('cyg_add')
                            cursor.execute(
                                "INSERT INTO dbo.FLOWBACK_CYGNET_SWITCH ([api],[date_to],[date_from],[source]) VALUES (?,?,?,?)",
                                row['api'], date_to, sql_date_to, 'cygnet')
                            connStr.commit()

                        else:
                            cyg_not = 'Cygnet Start Date is not available'

            cursor.close()
            connStr.close()
        else:
            Well_name_msg='Please Select Well Name'

#Adding Json File

    return render(request, 'switch.html', {'result': result, 'flow_not':flow_not, 'cyg_not':cyg_not, 'Well_name_msg':Well_name_msg })


def refresh(request):
# Start Well Filter
    result = {}
    for item in items:
        if item['pad'] in result:
            wells = result[item['pad']]
            if item['well_name'] not in wells:
                wells.append(item['well_name'])
        else:
            wells = []
            wells.append(item['well_name'])
            result[item['pad']] = wells
# End Well Filter

# Start API Filter
    result_api = {}
    for item in items:
        if item['well_name'] in result_api:
            wells = result_api[item['well_name']]

            if item['api'] not in wells:
                wells.append(item['api'])
        else:
            wells = []
            wells.append(item['api'])
            result_api[item['well_name']] = wells

# End API Filter
#Assinged Variable
    Well_name_ref_msg=''
    add_status = ''
    success_deleted=''
    date_valid=""
# Start Data Fetching
    if request.method == 'POST':
        start_date = request.POST['start_date']
        start_time = request.POST['start_time']
        end_date = request.POST['end_date']
        end_time = request.POST['end_time']
        well_item = request.POST.getlist('well_names')
        print(well_item)
        print(start_date)
        if well_item:
            print('API is There')


        #Checking Start date less then end date
            if start_date <= end_date:
         # DateTime assigning in one variable
                date_from = start_date + " " + start_time
                date_to = end_date + " " + end_time
        # Start API Validation with Well Name
                apis={}
                api_list = []
                for x in well_item:
                    if x in result_api:
                        for keys, values in result_api.items():
                            if x == keys:
                                api_list.append(values[0])
                apis['api'] = api_list
                apis.update(date_from=date_from)
                apis.update(date_to=date_to)
                apis.update(processed="false")
                # End API Validation with Well Name
                print(apis)


                dates= 'startdate='+start_date+" "+start_time+'&enddate='+end_date+" "+end_time
                add_dates= start_date+" "+start_time+'/'+end_date+" "+end_time
                print(add_dates)

        #Json and Parquet deletion



                url_delete=('http://10.28.1.29:7071/api/HttpTrigger1?'+dates)
                response = requests.get(url_delete)
                status=response.status_code
                print(status)
                if status == 200:
                    success_deleted='Successfully Deleted Json and Parquet File'

        # Add process start
                url_add = ('http://10.28.1.29:8011/api/values/' + add_dates)
                print(url_add)
                response = requests.get(url_add)
                status_add = response.status_code
                print(status_add)

                if status_add == 200:
                    add_status = 'Successfully Added'
    #Converting Json to DataFrame
                df = pd.DataFrame(apis)

    #Making Connection to Sql
                server = '10.14.0.16'
                database = 'sn-sql-pool'
                username = 'deorch@sogazcloud'
                password = 'DES0g!2345678'
                driver = '{ODBC Driver 17 for SQL Server}'
                connStr = pyodbc.connect(
                    'DRIVER=' + driver + ';SERVER=' + server + ';PORT=1433;DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
                cursor = connStr.cursor()
                print(cursor)
    #Inserting dataframe in sql
                for index, row in df.iterrows():
                    cursor.execute("INSERT INTO dbo.CYGNET_REFRESHED_RANGE ([api],[date_to],[date_from],[processed]) VALUES (?,?,?,?)", row['api'],
                                   row['date_to'], row['date_from'], row['processed'])
                    connStr.commit()
                cursor.close()
                connStr.close()

        #Serializing json with storing json logs in blob storage
            #Creating connection
                blob_service_client = BlockBlobService(
                    account_name='snazdl', account_key='+pgM4wsppBXuM2q2RTUjoziKjx2+WVJ7ShYuHQzCH9BY77uS4mxOXfjligO6yVUd+dOV0asuJ3UDj6q5gqg5gQ==')
                container_name = 'dev/CygnetRefreshedRange'

                local_path = './CygnetRefreshedRange'
                local_file_name = "refreshed.json"
                upload_file_path = os.path.join(local_path, local_file_name)
                print(upload_file_path)

                # Write text to the file
                with open(upload_file_path, 'a') as file:
                    file.write(json.dumps(apis))
                file.close()

                # Create a blob client using the local file name as the name for the blob
                blob_client = blob_service_client.create_blob_from_path(container_name, local_file_name, upload_file_path)

                print("\nUploading to Azure Storage as blob:\n\t" + local_path)



            else:
                date_valid='Incorrect Date entered'
                print(date_valid)
        else:
            Well_name_ref_msg = 'Please Select Well Name'


#Adding Json File

    return render(request, 'refresh.html', {'result': result, "add_status":add_status, 'Well_name_ref_msg':Well_name_ref_msg, 'success_deleted':success_deleted, 'date_valid':date_valid})